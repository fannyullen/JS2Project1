import AdminHeader from "../../components/Admin/AdminHeader";
import AdminForm from "../../components/Admin/AdminForm";

function AdminNewProduct() {
    return (
        <>
           <AdminHeader />
           <AdminForm />
        </>
    )
}

export default AdminNewProduct;